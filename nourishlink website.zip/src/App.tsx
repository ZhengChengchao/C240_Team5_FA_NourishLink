/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import Navbar from "./components/Navbar.tsx";
import Hero from "./components/Hero.tsx";
import ImpactStats from "./components/ImpactStats.tsx";
import OrgGrid from "./components/OrgGrid.tsx";
import Footer from "./components/Footer.tsx";
import FoodDonationModal from "./components/FoodDonationModal.tsx";
import MoneyDonationModal from "./components/MoneyDonationModal.tsx";
import DonorDashboard from "./components/DonorDashboard.tsx";
import OrgDashboard from "./components/OrgDashboard.tsx";
import { useAuthManager, UserRole } from "./lib/authStore.ts";
import { motion, AnimatePresence } from "motion/react";
import { 
  ArrowRight, 
  Globe, 
  Zap, 
  ShieldCheck, 
  Banknote, 
  ShoppingBag, 
  LogIn, 
  LayoutDashboard,
  Bell,
  UtensilsCrossed,
  PackageCheck,
  Heart,
  PlusCircle,
  HelpCircle
} from "lucide-react";

// Password Strength Evaluation Helpers
const CheckIcon = () => (
  <svg className="w-3.5 h-3.5 text-leaf-green shrink-0 fill-current" viewBox="0 0 20 20">
    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
  </svg>
);

const PendingIcon = () => (
  <svg className="w-3.5 h-3.5 text-charcoal/20 dark:text-white/20 shrink-0 fill-current" viewBox="0 0 20 20">
    <circle cx="10" cy="10" r="3" />
  </svg>
);

interface PasswordStrength {
  score: number;
  label: string;
  color: string;
  textColor: string;
  requirements: {
    length: boolean;
    mixed: boolean;
    digit: boolean;
    special: boolean;
  };
}

function evaluatePasswordStrength(pwd: string): PasswordStrength {
  const reqs = {
    length: pwd.length >= 8,
    mixed: /[a-z]/.test(pwd) && /[A-Z]/.test(pwd),
    digit: /[0-9]/.test(pwd),
    special: /[^A-Za-z0-9]/.test(pwd),
  };

  let score = 0;
  if (pwd.length > 0) {
    if (reqs.length) score += 1;
    if (reqs.mixed) score += 1;
    if (reqs.digit) score += 1;
    if (reqs.special) score += 1;
    // Length bonus for extra strength
    if (pwd.length >= 12 && score >= 2) score += 1;
  }

  const result = {
    score,
    requirements: reqs,
    label: "Empty",
    color: "bg-gray-200 dark:bg-zinc-750",
    textColor: "text-zinc-400 dark:text-zinc-500",
  };

  if (score === 0 && pwd.length > 0) {
    result.label = "Very Weak";
    result.color = "bg-red-500 animate-pulse";
    result.textColor = "text-red-500 font-bold";
  } else if (score === 1) {
    result.label = "Very Weak";
    result.color = "bg-red-500";
    result.textColor = "text-red-500 font-bold";
  } else if (score === 2) {
    result.label = "Weak";
    result.color = "bg-orange-500";
    result.textColor = "text-orange-500 font-bold";
  } else if (score === 3) {
    result.label = "Fair";
    result.color = "bg-amber-500";
    result.textColor = "text-amber-500 font-bold";
  } else if (score === 4) {
    result.label = "Strong";
    result.color = "bg-leaf-green";
    result.textColor = "text-leaf-green font-bold";
  } else if (score === 5) {
    result.label = "Very Strong";
    result.color = "bg-emerald-500";
    result.textColor = "text-emerald-500 dark:text-emerald-400 font-black";
  }

  return result;
}

export default function App() {
  const {
    currentUser,
    organizations,
    requests,
    donations,
    usersDb,
    login,
    register,
    logout,
    addDonation,
    createRequest,
    toggleRequestStatus,
    deleteRequest,
    updateGoal,
    resetPassword
  } = useAuthManager();

  const [theme, setTheme] = useState<"light" | "dark">(
    () => (typeof localStorage !== "undefined" ? (localStorage.getItem("nl_theme") as "light" | "dark") || "light" : "light")
  );

  React.useEffect(() => {
    const root = window.document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem("nl_theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === "light" ? "dark" : "light"));
  };

  const [currentTab, setCurrentTab] = useState("home");
  const [selectedOrg, setSelectedOrg] = useState<any>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successPayload, setSuccessPayload] = useState<{ orgName: string; type: string } | null>(null);
  const [isFoodModalOpen, setIsFoodModalOpen] = useState(false);
  const [isMoneyModalOpen, setIsMoneyModalOpen] = useState(false);

  // Auth local form states
  const [authTab, setAuthTab] = useState<"login" | "register" | "forgot">("login");
  const [roleTab, setRoleTab] = useState<"donor" | "organization">("donor");
  const [emailForm, setEmailForm] = useState("");
  const [passwordForm, setPasswordForm] = useState("");
  const [nameForm, setNameForm] = useState("");
  const [orgNameForm, setOrgNameForm] = useState("");
  const [orgTypeForm, setOrgTypeForm] = useState("Orphanage");
  const [authError, setAuthError] = useState("");
  const [authNotification, setAuthNotification] = useState("");

  // Forgot Password step state managers
  const [forgotStep, setForgotStep] = useState<1 | 2>(1);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotNewPassword, setForgotNewPassword] = useState("");
  const [linkSimulated, setLinkSimulated] = useState(false);

  const handleRequestResetLink = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthNotification("");
    if (!forgotEmail) {
      setAuthError("Please input your login email coordinates.");
      return;
    }
    const emailKey = forgotEmail.trim().toLowerCase();
    if (!usersDb[emailKey]) {
      setAuthError("No registered record found with this email coordinates.");
      return;
    }
    setLinkSimulated(true);
    setAuthNotification("Simulated SMTP Server Event: A recovery signature was compiled!");
  };

  const handleExecuteReset = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthNotification("");
    if (!forgotNewPassword) {
      setAuthError("Please format a new security password.");
      return;
    }
    const res = resetPassword(forgotEmail, forgotNewPassword);
    if (res.success) {
      setAuthNotification(res.message);
      // Pre-fill login info instantly
      setEmailForm(forgotEmail);
      setPasswordForm(forgotNewPassword);
      setForgotEmail("");
      setForgotNewPassword("");
      setForgotStep(1);
      setLinkSimulated(false);
      setTimeout(() => {
        setAuthTab("login");
        setAuthNotification("Passkey updated securely. Autofilled updated credentials below!");
      }, 1500);
    } else {
      setAuthError(res.message);
    }
  };

  const handleDonateSuccess = (details: { type: "food" | "money"; foodType?: string; quantity?: string; amount?: number; frequency?: string }) => {
    if (selectedOrg) {
      addDonation({
        orgName: selectedOrg.name,
        type: details.type,
        foodType: details.foodType,
        quantity: details.quantity,
        amount: details.amount,
        frequency: details.frequency as any
      });
      setSuccessPayload({ orgName: selectedOrg.name, type: details.type });
    }
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setSuccessPayload(null);
    }, 6000);
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthNotification("");

    if (!emailForm || !passwordForm) {
      setAuthError("Please fill out all required fields.");
      return;
    }

    if (authTab === "login") {
      const res = login(emailForm, passwordForm);
      if (res.success) {
        setAuthNotification(res.message);
        setEmailForm("");
        setPasswordForm("");
      } else {
        setAuthError(res.message);
      }
    } else {
      if (!nameForm) {
        setAuthError("Name is required to register an account.");
        return;
      }
      if (roleTab === "organization" && !orgNameForm) {
        setAuthError("Please enter the official name of your Organization.");
        return;
      }

      const res = register(
        emailForm,
        passwordForm,
        nameForm,
        roleTab,
        orgNameForm,
        orgTypeForm
      );

      if (res.success) {
        setAuthNotification(res.message);
        setEmailForm("");
        setPasswordForm("");
        setNameForm("");
        setOrgNameForm("");
      } else {
        setAuthError(res.message);
      }
    }
  };

  // Pre-fill helper for quick testing links
  const prefillTestAccount = (email: string, role: string) => {
    setEmailForm(email);
    setPasswordForm("password");
    setAuthTab("login");
    setAuthError("");
    setAuthNotification(`Prefilled login credentials for ${role}`);
  };

  const renderContent = () => {
    switch (currentTab) {
      case "home":
        return (
          <>
            <Hero 
              onDonate={() => setCurrentTab("give")} 
              onGetHelp={() => setCurrentTab("get-help")} 
            />
            
            <section className="py-24 bg-white">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="lg:flex items-center gap-24">
                  <div className="lg:w-1/2 mb-16 lg:mb-0">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-4 pt-12">
                         <div className="h-64 rounded-3xl bg-sdg-mustard/10 flex items-center justify-center overflow-hidden">
                            <img src="https://images.unsplash.com/photo-1547592166-23ac45744acd?q=80&w=400&fit=crop" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700" alt="Cooking" referrerPolicy="no-referrer" />
                         </div>
                         <div className="p-8 rounded-3xl border border-charcoal/5 bg-warm-white">
                            <Zap className="text-sdg-mustard mb-4" size={32} />
                            <h4 className="text-2xl font-serif mb-2">Real-time</h4>
                            <p className="text-sm text-charcoal/50">Immediate alerts for organizations in urgent need of logistics or food.</p>
                         </div>
                      </div>
                      <div className="space-y-4">
                         <div className="p-8 rounded-3xl bg-charcoal text-white">
                            <ShieldCheck className="text-leaf-green mb-4" size={32} />
                            <h4 className="text-2xl font-serif mb-2">Verified</h4>
                            <p className="text-sm text-white/50">We audit every donation center and orphanage on our platform.</p>
                         </div>
                         <div className="h-80 rounded-3xl bg-leaf-green/10 flex items-center justify-center overflow-hidden">
                            <img src="https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=400&fit=crop" className="w-full h-full object-cover saturate-50 hover:saturate-100 transition-all duration-700" alt="NGO Works" referrerPolicy="no-referrer" />
                         </div>
                      </div>
                    </div>
                  </div>
                  <div className="lg:w-1/2 space-y-8">
                    <div className="inline-flex items-center gap-2 text-sdg-mustard font-bold text-sm tracking-widest uppercase">
                       <Globe size={18} />
                       Our Commitment
                    </div>
                    <h2 className="text-5xl md:text-7xl font-serif leading-[0.9]">Bridging the gap to Zero Hunger.</h2>
                    <p className="text-xl text-charcoal/60 leading-relaxed">
                      World hunger isn't a supply problem; it's a logistics and transparency problem. NourishLink leverages technology to ensure food surplus reaches those who need it most efficiently.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
                      <div className="space-y-2">
                        <p className="text-4xl font-display font-bold text-leaf-green">828M</p>
                        <p className="text-xs uppercase font-bold tracking-widest opacity-40">People go hungry daily</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-4xl font-display font-bold text-sdg-mustard">1/3</p>
                        <p className="text-xs uppercase font-bold tracking-widest opacity-40">Of all food is wasted</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <ImpactStats />

            <section className="py-24 border-t border-charcoal/5">
               <div className="max-w-7xl mx-auto px-4 text-center">
                  <h2 className="text-5xl font-serif mb-16">The NourishLink Lifecycle</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
                     <div className="hidden md:block absolute top-[60px] left-[20%] right-[20%] h-px bg-dashed bg-charcoal/10" />
                     {[
                       { step: "01", title: "NGO Requests", desc: "Verified organizations list their urgent food needs." },
                       { step: "02", title: "Public Donates", desc: "Donors select an organization and contribute funds or food." },
                       { step: "03", title: "Last-Mile Delivery", desc: "Logistics partners ensure food reaches the right hands." }
                     ].map((s, i) => (
                       <div key={i} className="flex flex-col items-center relative z-10 group">
                          <div className="w-24 h-24 rounded-full bg-white border-2 border-charcoal/10 flex items-center justify-center font-display font-bold text-2xl text-sdg-mustard group-hover:border-sdg-mustard group-hover:scale-110 transition-all mb-6">
                            {s.step}
                          </div>
                          <h4 className="text-2xl font-serif mb-2">{s.title}</h4>
                          <p className="text-sm text-charcoal/50 max-w-xs">{s.desc}</p>
                       </div>
                     ))}
                  </div>
               </div>
            </section>

            <OrgGrid onSelect={(org) => { setSelectedOrg(org); setCurrentTab("give"); }} organizationsList={organizations} />
          </>
        );

      case "give":
        return (
          <div className="pt-32 pb-24 min-h-screen bg-warm-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="mb-16 text-center space-y-4">
                <h1 className="text-6xl font-serif">Support Those in Need</h1>
                <p className="text-charcoal/60 max-w-2xl mx-auto">
                  Browse verified organizations and donate funds or physical food items.
                  Your contribution goes directly to the selected cause.
                </p>
              </div>

              {selectedOrg && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mb-16 glass-card p-12 rounded-[3rem] relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-64 h-64 bg-sdg-mustard opacity-10 blur-3xl -translate-y-1/2 translate-x-1/2" />
                  <div className="md:flex gap-12 items-center relative z-10">
                    <div className="md:w-1/3 mb-8 md:mb-0">
                      <img src={selectedOrg.image} className="w-full aspect-square object-cover rounded-3xl shadow-xl border-4 border-white" />
                    </div>
                    <div className="md:w-2/3 space-y-6">
                      <div className="flex items-center justify-between">
                         <div>
                            <p className="text-sm font-bold text-leaf-green uppercase tracking-widest">{selectedOrg.type}</p>
                            <h2 className="text-5xl font-serif">{selectedOrg.name}</h2>
                         </div>
                         <button onClick={() => setSelectedOrg(null)} className="text-charcoal/30 hover:text-charcoal uppercase text-xs font-bold tracking-widest cursor-pointer">Select Another</button>
                      </div>
                      <p className="text-lg text-charcoal/70">{selectedOrg.description}</p>
                      
                      {/* Certified NGO Contact & Verification Dossier */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 p-6 bg-charcoal/5 rounded-3xl border border-charcoal/5 text-left">
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase text-charcoal/40 tracking-wider">Contact Coordinator</p>
                          <p className="text-sm font-bold text-charcoal">{selectedOrg.contactPersonName || "Official Representative"}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase text-charcoal/40 tracking-wider">Direct Verification Email</p>
                          <a 
                            href={`mailto:${selectedOrg.contactPersonEmail || "support@nourishlink.org"}`} 
                            className="text-sm font-bold text-leaf-green hover:underline block truncate"
                          >
                            {selectedOrg.contactPersonEmail || "verify@nourishlink.org"}
                          </a>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase text-charcoal/40 tracking-wider">Official Web Portal</p>
                          {selectedOrg.websiteUrl ? (
                            <a 
                              href={selectedOrg.websiteUrl} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-sm font-bold text-leaf-green hover:underline block truncate"
                            >
                              {selectedOrg.websiteUrl.replace("https://", "")}
                            </a>
                          ) : (
                            <span className="text-sm font-bold text-charcoal">NourishLink Partner</span>
                          )}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
                        <button 
                          onClick={() => setIsMoneyModalOpen(true)}
                          className="bg-charcoal text-white p-6 rounded-2xl flex items-center justify-between group hover:bg-sdg-mustard transition-colors text-left cursor-pointer"
                        >
                          <div>
                            <p className="font-bold text-xl mb-1">Donate Money</p>
                            <p className="text-xs opacity-60">One-time or recurring</p>
                          </div>
                          <Banknote size={32} className="group-hover:scale-110 transition-transform" />
                        </button>
                        <button 
                          onClick={() => setIsFoodModalOpen(true)}
                          className="bg-white border-2 border-charcoal/10 p-6 rounded-2xl flex items-center justify-between group hover:border-leaf-green hover:text-leaf-green transition-all text-left cursor-pointer"
                        >
                          <div>
                            <p className="font-bold text-xl mb-1">Donate Food</p>
                            <p className="text-xs opacity-60 font-medium">Drop-off or Pickup</p>
                          </div>
                          <ShoppingBag size={32} className="group-hover:scale-110 transition-transform" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {!selectedOrg && (
                <OrgGrid onSelect={setSelectedOrg} organizationsList={organizations} />
              )}
            </div>
            
            <FoodDonationModal 
              isOpen={isFoodModalOpen}
              onClose={() => setIsFoodModalOpen(false)}
              onSuccess={handleDonateSuccess}
              orgName={selectedOrg?.name || ""}
            />

            <MoneyDonationModal 
              isOpen={isMoneyModalOpen}
              onClose={() => setIsMoneyModalOpen(false)}
              onSuccess={handleDonateSuccess}
              orgName={selectedOrg?.name || ""}
            />
          </div>
        );

      case "get-help":
        return (
          <div className="pt-32 pb-24 min-h-screen bg-warm-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              {currentUser ? (
                currentUser.role === "donor" ? (
                  <DonorDashboard 
                    user={currentUser} 
                    onLogout={logout} 
                    donations={donations} 
                    onUpdateGoal={updateGoal} 
                  />
                ) : (
                  <OrgDashboard 
                    user={currentUser} 
                    onLogout={logout} 
                    requests={requests} 
                    donations={donations} 
                    organizations={organizations} 
                    onCreateRequest={createRequest} 
                    onToggleRequestStatus={toggleRequestStatus} 
                    onDeleteRequest={deleteRequest} 
                  />
                )
              ) : (
                <div className="w-full max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-12 bg-white rounded-[3rem] overflow-hidden shadow-2xl border border-charcoal/5">
                  {/* Form Column */}
                  <div className="p-10 md:p-14 md:col-span-7 flex flex-col justify-between space-y-8">
                    <div>
                      <div className="flex items-center gap-2 text-sdg-mustard text-xs font-bold uppercase tracking-widest mb-2">
                        <SparklesIcon />
                        Secure Authorization
                      </div>
                      <h2 className="text-4xl font-serif text-charcoal">
                        {authTab === "login" ? "Welcome back" : authTab === "register" ? "Create Giver Account" : "Reset Master Key"}
                      </h2>
                      <p className="text-charcoal/50 text-xs mt-1 leading-normal">
                        {authTab === "login" 
                          ? "Access your donation checkpoints or publish verified community hunger demands instantly." 
                          : authTab === "register"
                          ? "Join our tech-for-good mission. Track physical cargos or register coordinates."
                          : "Enter your coordinates to simulate a secure authorization override key."
                        }
                      </p>
                    </div>

                    {/* Auth Toggle Buttons */}
                    <div className="flex bg-gray-100 p-1.5 rounded-2xl w-full">
                      <button 
                        onClick={() => { setAuthTab("login"); setAuthError(""); setAuthNotification(""); setForgotStep(1); setLinkSimulated(false); }}
                        className={`flex-1 py-3 rounded-xl font-bold text-xs tracking-wide transition-all ${
                          authTab === "login" ? "bg-white text-charcoal shadow-sm" : "text-charcoal/40 hover:text-charcoal/60"
                        }`}
                      >
                        Account Login
                      </button>
                      <button 
                        onClick={() => { setAuthTab("register"); setAuthError(""); setAuthNotification(""); setForgotStep(1); setLinkSimulated(false); }}
                        className={`flex-1 py-3 rounded-xl font-bold text-xs tracking-wide transition-all ${
                          authTab === "register" ? "bg-white text-charcoal shadow-sm" : "text-charcoal/40 hover:text-charcoal/60"
                        }`}
                      >
                        New Registration
                      </button>
                    </div>

                    {authTab !== "forgot" ? (
                      <form onSubmit={handleAuthSubmit} className="space-y-4">
                        {authError && (
                          <div className="p-4 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs font-semibold">
                            ⚠️ {authError}
                          </div>
                        )}
                        
                        {authNotification && (
                          <div className="p-4 bg-green-50 border border-green-200 text-green-600 rounded-xl text-xs font-semibold">
                            ✓ {authNotification}
                          </div>
                        )}

                        {/* Registration Extra Fields */}
                        {authTab === "register" && (
                          <div className="grid grid-cols-1 gap-4">
                            <div className="space-y-1">
                              <label className="text-[10px] uppercase font-bold tracking-widest opacity-55 ml-1">My Full Name</label>
                              <input 
                                type="text" 
                                placeholder="e.g. Samuel Green" 
                                value={nameForm}
                                onChange={(e) => setNameForm(e.target.value)}
                                className="w-full border-b border-charcoal/10 focus:border-sdg-mustard outline-none py-2 px-1 transition-colors text-sm font-medium" 
                              />
                            </div>

                            <div className="space-y-2">
                              <label className="text-[10px] uppercase font-bold tracking-widest opacity-55 ml-1 block">Account Role</label>
                              <div className="grid grid-cols-2 gap-3">
                                <button
                                  type="button"
                                  onClick={() => setRoleTab("donor")}
                                  className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all ${
                                    roleTab === "donor" 
                                      ? "bg-leaf-green text-white border-leaf-green" 
                                      : "bg-white text-charcoal border-charcoal/10"
                                  }`}
                                >
                                  I want to Donate (Donor)
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setRoleTab("organization")}
                                  className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all ${
                                    roleTab === "organization" 
                                      ? "bg-sdg-mustard text-white border-sdg-mustard" 
                                      : "bg-white text-charcoal border-charcoal/10"
                                  }`}
                                >
                                  NGO Organization
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        <div className="space-y-1">
                          <label className="text-[10px] uppercase font-bold tracking-widest opacity-55 ml-1">Email Coordinates</label>
                          <input 
                            type="email" 
                            placeholder="your.email@example.com" 
                            value={emailForm}
                            onChange={(e) => setEmailForm(e.target.value)}
                            className="w-full border-b border-charcoal/10 focus:border-sdg-mustard outline-none py-2 px-1 transition-colors text-sm font-medium" 
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] uppercase font-bold tracking-widest opacity-55 ml-1">Password Credentials</label>
                          <input 
                            type="password" 
                            placeholder="••••••••" 
                            value={passwordForm}
                            onChange={(e) => setPasswordForm(e.target.value)}
                            className="w-full border-b border-charcoal/10 focus:border-sdg-mustard outline-none py-2 px-1 transition-colors text-sm font-medium" 
                          />
                        </div>

                        {authTab === "login" && (
                          <div className="flex justify-end pt-0.5">
                            <button
                              type="button"
                              onClick={() => {
                                setAuthTab("forgot");
                                setForgotStep(1);
                                setForgotEmail(emailForm || "");
                                setAuthError("");
                                setAuthNotification("");
                                setLinkSimulated(false);
                              }}
                              className="text-[11px] font-bold text-leaf-green hover:text-sdg-mustard hover:underline cursor-pointer transition-colors"
                            >
                              Forgot Password?
                            </button>
                          </div>
                        )}

                        {/* Password Strength Meter */}
                        {authTab === "register" && passwordForm && (() => {
                          const strength = evaluatePasswordStrength(passwordForm);
                          return (
                            <motion.div 
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="bg-charcoal/5 dark:bg-white/5 p-4 rounded-2xl border border-charcoal/5 dark:border-white/5 space-y-3 mt-2 overflow-hidden"
                            >
                              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                                <span className="opacity-55">Password Safety Status</span>
                                <span className={strength.textColor}>{strength.label}</span>
                              </div>

                              {/* Meter segments */}
                              <div className="grid grid-cols-5 gap-1.5">
                                {[1, 2, 3, 4, 5].map((index) => {
                                  const isActive = index <= strength.score;
                                  return (
                                    <div 
                                      key={index} 
                                      className={`h-1.5 rounded-sm transition-all duration-500 ease-out ${
                                        isActive ? strength.color : "bg-charcoal/10 dark:bg-white/10"
                                      }`}
                                    />
                                  );
                                })}
                              </div>

                              {/* Requirements checklist */}
                              <div className="grid grid-cols-2 gap-x-4 gap-y-2 pt-1 text-[10px] text-charcoal/60 dark:text-zinc-400 font-medium">
                                <div className="flex items-center gap-1.5">
                                  {strength.requirements.length ? <CheckIcon /> : <PendingIcon />}
                                  <span className={strength.requirements.length ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Min. 8 characters</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  {strength.requirements.mixed ? <CheckIcon /> : <PendingIcon />}
                                  <span className={strength.requirements.mixed ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Mixed (A-Z, a-z)</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  {strength.requirements.digit ? <CheckIcon /> : <PendingIcon />}
                                  <span className={strength.requirements.digit ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Contains number</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  {strength.requirements.special ? <CheckIcon /> : <PendingIcon />}
                                  <span className={strength.requirements.special ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Special symbol</span>
                                </div>
                              </div>
                            </motion.div>
                          );
                        })()}

                        {/* NGO Specific registration form blocks */}
                        {authTab === "register" && roleTab === "organization" && (
                          <div className="p-4 bg-sdg-mustard/5 rounded-2xl border border-sdg-mustard/15 space-y-3 animate-fade-in">
                            <p className="text-[10px] font-black uppercase text-sdg-mustard tracking-wider">NGO Verification Blueprint</p>
                            <div className="space-y-1">
                              <label className="text-[9px] uppercase font-extrabold tracking-widest opacity-55">NGO / Care Center Name</label>
                              <input 
                                type="text" 
                                placeholder="e.g. Compassion Shelter Home" 
                                value={orgNameForm}
                                onChange={(e) => setOrgNameForm(e.target.value)}
                                className="w-full bg-transparent border-b border-charcoal/10 focus:border-sdg-mustard outline-none py-1.5 px-0.5 text-xs font-bold" 
                              />
                            </div>
                            <div className="space-y-1 text-xs">
                              <label className="text-[9px] uppercase font-extrabold tracking-widest opacity-55 block">Center Classification</label>
                              <select 
                                value={orgTypeForm}
                                onChange={(e) => setOrgTypeForm(e.target.value)}
                                className="bg-transparent border-b border-charcoal/10 focus:border-sdg-mustard py-1.5 w-full outline-none font-medium"
                              >
                                <option value="Orphanage">Orphanage Home</option>
                                <option value="Food Bank">Food Bank Depot</option>
                                <option value="Elderly Care">Elderly Care Refuge</option>
                                <option value="Public Kitchen">Kitchen Collective</option>
                              </select>
                            </div>
                          </div>
                        )}

                        <button 
                          type="submit" 
                          className="w-full bg-charcoal text-white py-4 rounded-xl font-bold hover:bg-sdg-mustard hover:text-white transition-all flex items-center justify-center gap-2 text-sm select-none cursor-pointer shadow-md"
                        >
                          {authTab === "login" ? "Enter Private Dashboard" : "Register Credentials"}
                          <ArrowRight size={16} />
                        </button>
                      </form>
                    ) : (
                      /* FORGOT PASSWORD IMPLEMENTATION */
                      <div className="space-y-4">
                        {authError && (
                          <div className="p-4 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs font-semibold animate-fade-in">
                            ⚠️ {authError}
                          </div>
                        )}
                        
                        {authNotification && (
                          <div className="p-4 bg-green-50 border border-green-200 text-green-600 rounded-xl text-xs font-semibold animate-fade-in">
                            ✓ {authNotification}
                          </div>
                        )}

                        {forgotStep === 1 ? (
                          <form onSubmit={handleRequestResetLink} className="space-y-4">
                            <div className="space-y-1">
                              <label className="text-[10px] uppercase font-bold tracking-widest opacity-55 ml-1">Account Email Coordinates</label>
                              <input 
                                type="email" 
                                placeholder="e.g. jekytan1602@gmail.com" 
                                value={forgotEmail}
                                onChange={(e) => setForgotEmail(e.target.value)}
                                className="w-full border-b border-charcoal/10 focus:border-sdg-mustard outline-none py-2 px-1 transition-colors text-sm font-medium" 
                              />
                              <p className="text-[10px] text-charcoal/40 dark:text-zinc-400 mt-1">
                                Tips: You can use your custom email or any fast-track email profiles shown below.
                              </p>
                            </div>

                            <button 
                              type="submit" 
                              className="w-full bg-charcoal text-white py-3.5 rounded-xl font-bold hover:bg-sdg-mustard hover:text-white transition-all flex items-center justify-center gap-2 text-xs select-none cursor-pointer shadow-md"
                            >
                              <span>Send Simulated Reset Link</span>
                              <ArrowRight size={14} />
                            </button>

                            {linkSimulated && (
                              <div className="bg-leaf-green/5 dark:bg-emerald-950/20 border border-leaf-green/20 rounded-2xl p-4.5 space-y-3.5 text-left animate-fade-in">
                                <div className="flex items-center justify-between text-[10px] font-bold text-leaf-green">
                                  <span className="flex items-center gap-1.5 uppercase tracking-widest text-[9px]">
                                    <span className="w-1.5 h-1.5 rounded-full bg-leaf-green animate-ping" />
                                    Simulated Mail Delivery
                                  </span>
                                  <span className="opacity-55">SMTP Localhost #3000</span>
                                </div>
                                <div className="text-xs space-y-1.5 text-charcoal/80 dark:text-zinc-300">
                                  <p><strong>To:</strong> <span className="underline">{forgotEmail}</span></p>
                                  <p><strong>Subject:</strong> Password reset directive</p>
                                  <p className="opacity-75 leading-relaxed text-[11px] pt-1">
                                    NourishLink compiled an auth override sequence. Click below to proceed with the password format instruction:
                                  </p>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setForgotStep(2);
                                    setAuthError("");
                                    setAuthNotification("Simulated link verified. Choose a secure new passkey:");
                                  }}
                                  className="w-full bg-leaf-green hover:bg-emerald-600 text-white py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow flex items-center justify-center gap-1.5"
                                >
                                  <span>Proceed to Password Reset</span>
                                  <ArrowRight size={12} />
                                </button>
                              </div>
                            )}
                          </form>
                        ) : (
                          <form onSubmit={handleExecuteReset} className="space-y-4">
                            <div className="space-y-1">
                              <label className="text-[10px] uppercase font-bold tracking-widest opacity-55 ml-1">New Password Credentials</label>
                              <input 
                                type="password" 
                                placeholder="••••••••" 
                                value={forgotNewPassword}
                                onChange={(e) => setForgotNewPassword(e.target.value)}
                                className="w-full border-b border-charcoal/10 focus:border-sdg-mustard outline-none py-2 px-1 transition-colors text-sm font-medium animate-fade-in" 
                              />
                            </div>

                            {/* Password Strength Meter for Forgot Password Input */}
                            {forgotNewPassword && (() => {
                              const strength = evaluatePasswordStrength(forgotNewPassword);
                              return (
                                <motion.div 
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: "auto" }}
                                  exit={{ opacity: 0, height: 0 }}
                                  className="bg-charcoal/5 dark:bg-white/5 p-4 rounded-2xl border border-charcoal/5 dark:border-white/5 space-y-3 mt-2 overflow-hidden"
                                >
                                  <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                                    <span className="opacity-55">Password Safety Status</span>
                                    <span className={strength.textColor}>{strength.label}</span>
                                  </div>

                                  {/* Meter segments */}
                                  <div className="grid grid-cols-5 gap-1.5">
                                    {[1, 2, 3, 4, 5].map((index) => {
                                      const isActive = index <= strength.score;
                                      return (
                                        <div 
                                          key={index} 
                                          className={`h-1.5 rounded-sm transition-all duration-500 ease-out ${
                                            isActive ? strength.color : "bg-charcoal/10 dark:bg-white/10"
                                          }`}
                                        />
                                      );
                                    })}
                                  </div>

                                  {/* Requirements checklist */}
                                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 pt-1 text-[10px] text-charcoal/60 dark:text-zinc-400 font-medium">
                                    <div className="flex items-center gap-1.5">
                                      {strength.requirements.length ? <CheckIcon /> : <PendingIcon />}
                                      <span className={strength.requirements.length ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Min. 8 characters</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                      {strength.requirements.mixed ? <CheckIcon /> : <PendingIcon />}
                                      <span className={strength.requirements.mixed ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Mixed (A-Z, a-z)</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                      {strength.requirements.digit ? <CheckIcon /> : <PendingIcon />}
                                      <span className={strength.requirements.digit ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Contains number</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                      {strength.requirements.special ? <CheckIcon /> : <PendingIcon />}
                                      <span className={strength.requirements.special ? "text-leaf-green dark:text-leaf-green/90 font-bold" : "opacity-70"}>Special symbol</span>
                                    </div>
                                  </div>
                                </motion.div>
                              );
                            })()}

                            <button 
                              type="submit" 
                              className="w-full bg-leaf-green text-white py-3.5 rounded-xl font-bold hover:bg-emerald-600 transition-all flex items-center justify-center gap-2 text-xs select-none cursor-pointer shadow-md"
                            >
                              <span>Update Passkey Coordinates</span>
                              <ArrowRight size={14} />
                            </button>
                          </form>
                        )}

                        <div className="flex justify-center pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              setAuthTab("login");
                              setForgotEmail("");
                              setForgotNewPassword("");
                              setForgotStep(1);
                              setLinkSimulated(false);
                              setAuthError("");
                              setAuthNotification("");
                            }}
                            className="text-xs font-bold text-charcoal/40 hover:text-charcoal/70 transition-colors cursor-pointer hover:underline"
                          >
                            ← Cancel and Return to Login
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Developer Account Bypass Link Block */}
                    <div className="pt-4 border-t border-charcoal/5 space-y-3">
                      <p className="text-[10px] uppercase font-extrabold tracking-widest text-charcoal/40 text-center">Fast-track verification accounts:</p>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[10px] font-bold">
                        <button 
                          onClick={() => prefillTestAccount("jekytan1602@gmail.com", "Main Donor")}
                          className="p-2 border border-leaf-green/20 hover:border-leaf-green bg-leaf-green/5 text-leaf-green rounded-xl transition-all cursor-pointer text-center"
                        >
                          👤 Jeky Tan (Donor)
                        </button>
                        <button 
                          onClick={() => prefillTestAccount("hope@children.org", "Hope Children (NGO)")}
                          className="p-2 border border-sdg-mustard/20 hover:border-sdg-mustard bg-sdg-mustard/5 text-sdg-mustard rounded-xl transition-all cursor-pointer text-center"
                        >
                          🏘️ Hope NGO Office
                        </button>
                        <button 
                          onClick={() => prefillTestAccount("metro@foodalliance.org", "Metro Alliance")}
                          className="p-2 border border-blue-500/20 hover:border-blue-500 bg-blue-50 text-blue-500 rounded-xl transition-all cursor-pointer text-center col-span-2 sm:col-span-1"
                        >
                          🥗 Metro Depot Center
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Informational Column */}
                  <div className="hidden md:block md:col-span-5 bg-leaf-green p-12 text-white space-y-8 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-full h-full opacity-15 pointer-events-none select-none">
                      <img src="https://images.unsplash.com/photo-1542810634-71277d95dcbb?q=80&w=600&fit=crop" className="w-full h-full object-cover" alt="Support" referrerPolicy="no-referrer" />
                    </div>
                    
                    <div className="relative z-10 space-y-10 py-4 flex flex-col h-full justify-between">
                      <div className="space-y-4">
                        <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur">
                          <LayoutDashboard size={22} />
                        </div>
                        <h3 className="text-3xl font-serif">A Unified Dashboard to Manage Change</h3>
                        <p className="text-white/80 text-xs leading-relaxed">
                          Whether you want to sponsor life-saving commodities or request high nutrition meals for children under your care, our secure portal helps maintain immediate trust and full accountability.
                        </p>
                      </div>

                      <div className="space-y-4 pt-4 border-t border-white/10">
                         <div className="flex items-center gap-2">
                           <div className="w-1.5 h-1.5 rounded-full bg-sdg-mustard animate-pulse" />
                           <p className="text-[9px] font-black uppercase tracking-widest text-sdg-mustard">NourishLink Core Utilities</p>
                         </div>
                         <div className="space-y-4">
                           {[
                             { icon: Bell, t: "Real-time Notifications", d: "Caretakers instantly get notified when bulk food matches are verified." },
                             { icon: UtensilsCrossed, t: "Nutritional Auditing", d: "Track dietary requirements like proteins, soy items, and grains." },
                             { icon: PackageCheck, t: "Automatic Progress Scaling", d: "Successful donor drop-offs automatically scale the public progress index." }
                           ].map((item, i) => (
                             <div key={i} className="flex gap-3">
                               <item.icon className="text-sdg-mustard shrink-0" size={18} />
                               <div>
                                 <p className="font-bold text-xs">{item.t}</p>
                                 <p className="text-[10px] opacity-75 leading-normal mt-0.5">{item.d}</p>
                               </div>
                             </div>
                           ))}
                         </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case "impact":
        return (
          <div className="pt-32 pb-24 min-h-screen bg-warm-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
               <div className="mb-24 text-center space-y-4">
                  <h1 className="text-7xl font-serif leading-none tracking-tight">Our Radical <br /><span className="text-leaf-green italic">Transparency.</span></h1>
                  <p className="text-charcoal/60 max-w-xl mx-auto text-lg pt-4">
                    Every donation is traceable. We use ledger-inspired logging to ensure that 100% of your gift reaches the target.
                  </p>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
                  <div className="space-y-12">
                     <div className="space-y-6">
                        <div className="flex items-center gap-4 text-sdg-mustard font-bold uppercase tracking-widest text-sm">
                           01. THE TECH
                        </div>
                        <h2 className="text-4xl font-serif">Smart Inventory Routing</h2>
                        <p className="text-charcoal/60 leading-relaxed">
                          Our algorithms analyze wholesale surplus data and match it with real-time NGO requests. This reduces logistics waste and ensures food reaches communities quickly.
                        </p>
                     </div>
                     <div className="space-y-6 pt-12 border-t border-charcoal/5">
                        <div className="flex items-center gap-4 text-leaf-green font-bold uppercase tracking-widest text-sm">
                           02. THE METRIC
                        </div>
                        <h2 className="text-4xl font-serif">Nutritional ROI</h2>
                        <p className="text-charcoal/60 leading-relaxed">
                          We don't just measure total pounds of food donated. We track Nutritional Units – ensuring that growing children and elderly groups receive the exact macronutrients needed.
                        </p>
                     </div>
                  </div>
                  <div className="relative">
                     <div className="h-[600px] rounded-[3rem] bg-charcoal overflow-hidden p-8 flex flex-col justify-between">
                        <div className="space-y-2">
                           <p className="text-white font-bold text-sm uppercase tracking-widest opacity-40">Live Network Traffic</p>
                           <div className="flex gap-1 h-32 items-end">
                              {[...Array(20)].map((_, i) => (
                                <motion.div 
                                  key={i}
                                  initial={{ height: 0 }}
                                  animate={{ height: `${Math.random() * 100 + 10}%` }}
                                  transition={{ repeat: Infinity, duration: 1, repeatType: "reverse", delay: i * 0.05 }}
                                  className="flex-1 bg-sdg-mustard/40 rounded-t-sm"
                                />
                              ))}
                           </div>
                        </div>
                        <div className="aspect-video rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                            <Globe className="text-white/20 animate-spin-slow" size={120} />
                        </div>
                        <div className="space-y-4">
                           <div className="flex justify-between items-center text-white/50 text-xs font-bold uppercase tracking-widest">
                              <span>System Status</span>
                              <span className="text-leaf-green flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-leaf-green" />
                                Optimal
                              </span>
                           </div>
                           <div className="grid grid-cols-2 gap-4">
                              <div className="bg-white/5 p-4 rounded-xl">
                                 <p className="text-white font-display text-2xl font-bold">1.2s</p>
                                 <p className="text-[10px] text-white/30 uppercase font-bold tracking-tight">Average Response Time</p>
                              </div>
                              <div className="bg-white/5 p-4 rounded-xl">
                                 <p className="text-white font-display text-2xl font-bold">100%</p>
                                 <p className="text-[10px] text-white/30 uppercase font-bold tracking-tight">Donation Transparency</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     {/* Floating Badge */}
                     <div className="absolute -bottom-6 -right-6 p-8 rounded-full bg-sdg-mustard text-white font-display font-black text-center leading-none">
                        98% <br /><span className="text-[10px] font-bold uppercase tracking-tighter opacity-80">Accuracy</span>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-warm-white">
      <Navbar 
        currentTab={currentTab} 
        setTab={setCurrentTab} 
        currentUser={currentUser}
        onLogout={logout}
        theme={theme}
        onToggleTheme={toggleTheme}
      />
      
      <AnimatePresence mode="wait">
        <motion.main
          key={currentTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
        >
          {renderContent()}
        </motion.main>
      </AnimatePresence>

      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[100] w-[90%] max-w-md"
          >
            <div className="bg-leaf-green text-white p-6 rounded-3xl shadow-2xl flex items-center gap-6 border-4 border-white">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                <Heart className="fill-white" size={32} />
              </div>
              <div>
                <h4 className="text-2xl font-serif">Thank you!</h4>
                <p className="text-xs opacity-90 leading-tight">
                  {currentUser ? `${currentUser.name}, your ` : "Your "} 
                  {successPayload?.type === "money" ? "financial gift" : "food donation"} has been registered for {successPayload?.orgName || "the organization"}. Together, we move closer to Zero Hunger!
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  );
}

// Compact helper vector Icons for clean decorations
function SparklesIcon() {
  return (
    <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
      <path d="M12 2l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4-3.9-3.8 5.4-.8zm0 4.2l-1.1 2.2-2.5.4 1.8 1.8-.4 2.5 2.2-1.2 2.2 1.2-.4-2.5 1.8-1.8-2.5-.4z"/>
    </svg>
  );
}
